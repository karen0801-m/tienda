package co.edu.unbosque.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import co.edu.unbosque.dto.ProveedorDTO;

public class ProveedorDAO implements ICrud {

	private List<ProveedorDTO> listaproveedor;

	public List<ProveedorDTO> getListaproveedor() {
		return listaproveedor;
	}

	public void setListaproveedor(List<ProveedorDTO> listaproveedor) {
		this.listaproveedor = listaproveedor;
	}
	
	private void listarProveedor(List<ProveedorDTO> listaproveedor) {
		for (ProveedorDTO proveedor : listaproveedor) {
			//aca se pone la funcion para mostrar en pantalla
		}
	}

	@Override
	public String agregar(Object registro) {
		
		String resultado;
		SessionFactory miFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(ProveedorDTO.class).buildSessionFactory();

		Session miSession = miFactory.openSession();
		try {
			miSession.beginTransaction();
			miSession.save((ProveedorDTO) registro);
			miSession.getTransaction().commit();
			resultado = "OK";
			miSession.close();
		} catch (Exception e) {
			resultado = e.toString();
		} finally {
			miFactory.close();
		}
		return resultado;

	}

	@Override
	public String actualizar(Object id, Object registro) {
		String resultado;
		SessionFactory miFactory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(ProveedorDTO.class)
				.buildSessionFactory();
		Session miSession = miFactory.openSession();

		try {
			miSession.beginTransaction();
			ProveedorDTO miCliente = miSession.get(ProveedorDTO.class, (int)id);
			miCliente = (ProveedorDTO) registro;
			miSession.getTransaction().commit();
			resultado = "OK";
			miSession.close();
		} catch (Exception e) {
			resultado = e.toString();
		} finally {
			miFactory.close();
		}		
		return resultado;
	
	}

	@Override
	public String eliminar(Object id) {
		// TODO Auto-generated method stub
		String resultado;
		SessionFactory miFactory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(ProveedorDTO.class)
				.buildSessionFactory();
		Session miSession = miFactory.openSession();

		try {
			miSession.beginTransaction();
			miSession.createQuery("delete proveedores where id="+(int)id).executeUpdate();
			miSession.getTransaction().commit();
			resultado = "OK";
			miSession.close();
		} catch (Exception e) {
			resultado = e.toString();
		} finally {
			miFactory.close();
		}		
		return resultado;
	}

	@Override
	public Object consultar() {
		// TODO Auto-generated method stub
		SessionFactory miFactory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(ProveedorDTO.class)
				.buildSessionFactory();
		Session miSession = miFactory.openSession();
		try {
			miSession.beginTransaction();
			listaproveedor = miSession.createQuery("from ProveedorDTO").getResultList();
			listarProveedor(listaproveedor);
			miSession.getTransaction().commit();
			miSession.close();
		} catch (Exception e) {
			listaproveedor=null;
			//resultado = e.toString();
		} finally {
			miFactory.close();
		}		
		return listaproveedor;
	}
	
	public int generarId() {
		int id;
		SessionFactory miFactory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(ProveedorDTO.class)
				.buildSessionFactory();
		Session miSession = miFactory.openSession();

		try {
			miSession.beginTransaction();
			Query query = miSession.createQuery("select max(id)+1 as id from ProveedorDTO");
			List numeros = query.getResultList();
			id = (int)numeros.get(0);
			miSession.close();
		} catch (Exception e) {
			id = 1;
		} finally {
			miFactory.close();
		}		
		return id;		
	}

}
