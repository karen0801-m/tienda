package co.edu.unbosque.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "proveedores")
public class ProveedorDTO {
	@Id
	@Column(name = "id")
	private int id;

	@Column(name = "nombre")
	private String nombre;

	@Column(name = "NIT")
	private long NIT;

	@Column(name = "direccion")
	private String direccion;

	@Column(name = "telefono")
	private long telefono;

	@Column(name = "ciudad")
	private String ciudad;

	public ProveedorDTO() {
		// TODO Auto-generated constructor stub
	}

	public ProveedorDTO(int id, String nombre, long nIT, String direccion, long telefono, String ciudad) {
		super();
		this.id = id;
		this.nombre = nombre;
		NIT = nIT;
		this.direccion = direccion;
		this.telefono = telefono;
		this.ciudad = ciudad;
	}

	@Override
	public String toString() {
		return "ProveedorDTO [id=" + id + ", nombre=" + nombre + ", NIT=" + NIT + ", direccion=" + direccion
				+ ", telefono=" + telefono + ", ciudad=" + ciudad + "]";
	}

	public int getId() {
		return id;
	}

	public String getNombre() {
		return nombre;
	}

	public long getNIT() {
		return NIT;
	}

	public String getDireccion() {
		return direccion;
	}

	public long getTelefono() {
		return telefono;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setNIT(long nIT) {
		NIT = nIT;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public void setTelefono(long telefono) {
		this.telefono = telefono;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

}
