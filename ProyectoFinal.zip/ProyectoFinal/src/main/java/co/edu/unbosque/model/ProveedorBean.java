package co.edu.unbosque.model;

import java.util.List;

import co.edu.unbosque.dao.ClienteDAO;
import co.edu.unbosque.dao.ProveedorDAO;
import co.edu.unbosque.dto.ClienteDTO;
import co.edu.unbosque.dto.ProveedorDTO;
import javax.faces.bean.ManagedBean;

@ManagedBean
public class ProveedorBean {

	private int id;
	private String nombre;
	private long NIT;
	private String direccion;
	private long telefono;
	private String ciudad;
	private String resultado;
	private List<ProveedorDTO> listaprovedor;
	

	public ProveedorBean() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public String getNombre() {
		return nombre;
	}

	public long getNIT() {
		return NIT;
	}

	public String getDireccion() {
		return direccion;
	}

	public long getTelefono() {
		return telefono;
	}

	public String getCiudad() {
		return ciudad;
	}

	public String getResultado() {
		return resultado;
	}

	public List<ProveedorDTO> getListaproveedor() {
		return listaprovedor;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setNIT(long nIT) {
		NIT = nIT;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public void setTelefono(long telefono) {
		this.telefono = telefono;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}

	public void setListaclientes(List<ProveedorDTO> listaproveedor) {
		this.listaprovedor = listaproveedor;
	}
	
	public String agregar() {
		ProveedorDAO pr = new ProveedorDAO();
		this.id = pr.generarId();
		this.resultado = pr.agregar(new ProveedorDTO(this.id, this.nombre, NIT, this.ciudad, this.telefono, this.direccion));
		this.listaprovedor = (List<ProveedorDTO>)pr.consultar();
		if(this.resultado.equals("OK") && this.listaprovedor!=null) {
			return "proveedores.xhtml";
		}
		else {
			return "error.xhtml";
		}
			
	}
	
	public String eliminar(String id) {
	     ProveedorDAO pr = new ProveedorDAO();
	    String resultado = pr.eliminar(id);
	    this.listaprovedor = (List<ProveedorDTO>) pr.consultar();
	    
	    if (resultado.equals("OK")) {
	        return "tienda.xhtml";
	    } else {
	        return "error.xhtml";
	    }
	}
	
	public String actualizar() {
	    ProveedorDAO pr = new ProveedorDAO();
	    ProveedorDTO tienda = new ProveedorDTO(this.id, this.nombre, NIT, this.ciudad, this.telefono, this.direccion);
	    String resultado = pr.actualizar(this.id, tienda);
	    this.listaprovedor = (List<ProveedorDTO>) pr.consultar();
	    
	    if (resultado.equals("OK")) {
	        return "tienda.xhtml";
	    } else {
	        return "error.xhtml";
	    }
	}
	
	public String consultar() {
		ProveedorDAO cl = new ProveedorDAO();
		this.listaprovedor = (List<ProveedorDTO>)cl.consultar();
		if(this.listaprovedor!=null) {
			return "proveedores.xhtml";
		}
		else {
			return "error.xhtml";
		}
	}

}
