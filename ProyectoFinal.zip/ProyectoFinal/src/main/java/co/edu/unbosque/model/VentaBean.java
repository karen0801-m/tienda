package co.edu.unbosque.model;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class VentaBean {
	
	private String opcionSeleccionada;
    private boolean formularioDeshabilitado;
    
    public String getOpcionSeleccionada() {
        return opcionSeleccionada;
    }

    public void setOpcionSeleccionada(String opcionSeleccionada) {
        this.opcionSeleccionada = opcionSeleccionada;
    }

    public boolean isFormularioDeshabilitado() {
        return formularioDeshabilitado;
    }

    public void setFormularioDeshabilitado(boolean formularioDeshabilitado) {
        this.formularioDeshabilitado = formularioDeshabilitado;
    }
	
	public void handleRadioChange() {
  		if ("opcion1".equals(opcionSeleccionada)) {
    		formularioDeshabilitado = true;
  		} else {
    		formularioDeshabilitado = false;
  		}
	}
}
