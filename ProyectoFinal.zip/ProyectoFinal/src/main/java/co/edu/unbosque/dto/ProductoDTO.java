package co.edu.unbosque.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "productos")
public class ProductoDTO {
	@Id
	@Column(name = "id")
	private int id;
	
	@Column (name = "codigo_producto")
	private long codigo_producto;
	
	@Column (name= "nombre")
	private String  nombre;
	
	@Column (name="NIT_prod")
	private long NIT_prod;
	
	@Column (name="nombre_prov")
	private String nombre_prov;
	
	@Column (name="precio_com")
	private long precio_com;
	
	@Column (name="precio_ven")
	private long precio_ven;

	public ProductoDTO(int id, long codigo_producto, String nombre, long nIT_prod, String nombre_prov, long precio_com,
			long precio_ven) {
		super();
		this.id = id;
		this.codigo_producto = codigo_producto;
		this.nombre = nombre;
		NIT_prod = nIT_prod;
		this.nombre_prov = nombre_prov;
		this.precio_com = precio_com;
		this.precio_ven = precio_ven;
	}

	public ProductoDTO() {
		
	}

	@Override
	public String toString() {
		return "ProductoDTO [id=" + id + ", codigo_producto=" + codigo_producto + ", nombre=" + nombre + ", NIT_prod="
				+ NIT_prod + ", nombre_prov=" + nombre_prov + ", precio_com=" + precio_com + ", precio_ven="
				+ precio_ven + "]";
	}

	public int getId() {
		return id;
	}

	public long getCodigo_producto() {
		return codigo_producto;
	}

	public String getNombre() {
		return nombre;
	}

	public long getNIT_prod() {
		return NIT_prod;
	}

	public String getNombre_prov() {
		return nombre_prov;
	}

	public long getPrecio_com() {
		return precio_com;
	}

	public long getPrecio_ven() {
		return precio_ven;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setCodigo_producto(long codigo_producto) {
		this.codigo_producto = codigo_producto;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setNIT_prod(long nIT_prod) {
		NIT_prod = nIT_prod;
	}

	public void setNombre_prov(String nombre_prov) {
		this.nombre_prov = nombre_prov;
	}

	public void setPrecio_com(long precio_com) {
		this.precio_com = precio_com;
	}

	public void setPrecio_ven(long precio_ven) {
		this.precio_ven = precio_ven;
	}
	
	

}
