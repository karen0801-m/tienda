package co.edu.unbosque.model;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class ErrorBean{
	
	public String volver(){
		
		return "index.xhtml";
	}
}