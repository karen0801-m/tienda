package co.edu.unbosque.model;

import java.util.List;

import co.edu.unbosque.dao.TiendaDAO;
import co.edu.unbosque.dto.ClienteDTO;
import co.edu.unbosque.dto.ProveedorDTO;
import co.edu.unbosque.dto.TiendaDTO;
import javax.faces.bean.ManagedBean;

@ManagedBean
public class TiendaBean {
	private int id;
	private String nombre;
	private String tipo_tienda;
	private long NIT;
	private String ciudad;
	private float valor_IVA;
	private float tasa_int;
	private String banco;
	private long numerocuen;
	private String gerente;
	private String resultado;
	private List<TiendaDTO> listatienda;

	public int getId() {
		return id;
	}

	public String getNombre() {
		return nombre;
	}

	public String getTipo_tienda() {
		return tipo_tienda;
	}

	public long getNIT() {
		return NIT;
	}

	public String getCiudad() {
		return ciudad;
	}

	public float getValor_IVA() {
		return valor_IVA;
	}

	public float getTasa_int() {
		return tasa_int;
	}

	public String getBanco() {
		return banco;
	}

	public long getNumerocuen() {
		return numerocuen;
	}

	public String getGerente() {
		return gerente;
	}

	public List<TiendaDTO> getListatienda() {
		return listatienda;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setTipo_tienda(String tipo_tienda) {
		this.tipo_tienda = tipo_tienda;
	}

	public void setNIT(long nIT) {
		NIT = nIT;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public void setValor_IVA(float valor_IVA) {
		this.valor_IVA = valor_IVA;
	}

	public void setTasa_int(float tasa_int) {
		this.tasa_int = tasa_int;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public void setNumerocuen(long numerocuen) {
		this.numerocuen = numerocuen;
	}

	public void setGerente(String gerente) {
		this.gerente = gerente;
	}

	public void setListatienda(List<TiendaDTO> listatienda) {
		this.listatienda = listatienda;
	}
	
	
	
	public String getResultado() {
		return resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}

	public String agregar() {
		
		
		TiendaDAO td = new TiendaDAO();
		this.id = td.generarId();
		this.resultado = td.agregar(new TiendaDTO(this.id, this.nombre, this.tipo_tienda, NIT, this.ciudad, valor_IVA , tasa_int, this.banco, numerocuen, this.gerente));
		this.listatienda = (List<TiendaDTO>)td.consultar();
		
		if(this.listatienda != null) {
			return "tienda.xhtml";
		}
		else {
			return "index.xhtml";
		}
			
	}
	
	public String eliminar(String id) {
	     TiendaDAO td = new TiendaDAO();
	    String resultado = td.eliminar(id);
	    this.listatienda = (List<TiendaDTO>) td.consultar();
	    
	    if (resultado.equals("OK")) {
	        return "tienda.xhtml";
	    } else {
	        return "error.xhtml";
	    }
	}
	
	public String actualizar() {
	    TiendaDAO cl = new TiendaDAO();
	    TiendaDTO tienda = new TiendaDTO(this.id, this.nombre, this.tipo_tienda, NIT, this.ciudad, valor_IVA , tasa_int, this.banco, numerocuen, this.gerente);
	    String resultado = cl.actualizar(this.id, tienda);
	    this.listatienda = (List<TiendaDTO>) cl.consultar();
	    
	    if (resultado.equals("OK")) {
	        return "tienda.xhtml";
	    } else {
	        return "error.xhtml";
	    }
	}
	
	public String consultar() {
		TiendaDAO td = new TiendaDAO();
		this.listatienda = (List<TiendaDTO>)td.consultar();
		if(this.listatienda != null) {
			return "tienda.xhtml";
		}
		else {
			return "error.xhtml";
		}
	}

}
