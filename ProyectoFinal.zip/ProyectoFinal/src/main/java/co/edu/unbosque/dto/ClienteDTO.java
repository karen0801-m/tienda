package co.edu.unbosque.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "clientes")

public class ClienteDTO {
	@Id
	@Column(name = "id")
	private int id;

	@Column(name = "cedula")
	private int cedula;

	@Column(name = "nombre")
	private String nombre;

	@Column(name = "direccion")
	private String direccion;

	@Column(name = "telefono")
	private long telefono;

	@Column(name = "correo")
	private String correo;

	public ClienteDTO() {
		// TODO Auto-generated constructor stub
	}

	public ClienteDTO(int id, int cedula, String nombre, String direccion, long telefono, String correo) {
		super();
		this.id = id;
		this.cedula = cedula;
		this.nombre = nombre;
		this.direccion = direccion;
		this.telefono = telefono;
		this.correo = correo;
	}

	@Override
	public String toString() {
		return "ClienteDTO [id=" + id + ", cedula=" + cedula + ", nombre=" + nombre + ", direccion=" + direccion
				+ ", telefono=" + telefono + ", correo=" + correo + "]";
	}

	public int getId() {
		return id;
	}
	
	

	public int getCedula() {
		return cedula;
	}

	public String getNombre() {
		return nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public long getTelefono() {
		return telefono;
	}

	public String getCorreo() {
		return correo;
	}

	public void setId(int id) {
		this.id = id;
	}
	

	public void setCedula(int cedula) {
		this.cedula = cedula;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public void setTelefono(long telefono) {
		this.telefono = telefono;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

}
