package co.edu.unbosque.dao;

import co.edu.unbosque.dto.ProductoDTO;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import javax.faces.bean.ManagedBean;

@ManagedBean
public class ProductoDAO implements ICrud {

	private List<ProductoDTO> listaproducto;

	public List<ProductoDTO> getListaproducto() {
		return listaproducto;
	}

	public void setListaproducto(List<ProductoDTO> listaproducto) {
		this.listaproducto = listaproducto;
	}

	public void listarproducto(List<ProductoDTO> listaproducto) {
		for (ProductoDTO producto : listaproducto) {
			// aca se pone la funcion para mostrar en pantalla
		}
	}

	@Override
	public String agregar(Object registro) {
		String resultado;
		SessionFactory miFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(ProductoDTO.class).buildSessionFactory();

		Session miSession = miFactory.openSession();
		try {
			miSession.beginTransaction();
			miSession.save((ProductoDTO) registro);
			miSession.getTransaction().commit();
			resultado = "OK";
			miSession.close();
		} catch (Exception e) {
			resultado = e.toString();
		} finally {
			miFactory.close();
		}
		return resultado;
	}

	@Override
	public String actualizar(Object id, Object registro) {
		String resultado;
		SessionFactory miFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(ProductoDTO.class).buildSessionFactory();
		Session miSession = miFactory.openSession();

		try {
			miSession.beginTransaction();
			ProductoDTO miCliente = miSession.get(ProductoDTO.class, (int) id);
			miCliente = (ProductoDTO) registro;
			miSession.getTransaction().commit();
			resultado = "OK";
			miSession.close();
		} catch (Exception e) {
			resultado = e.toString();
		} finally {
			miFactory.close();
		}
		return resultado;

	}

	@Override
	public String eliminar(Object id) {
		// TODO Auto-generated method stub
		String resultado;
		SessionFactory miFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(ProductoDTO.class).buildSessionFactory();
		Session miSession = miFactory.openSession();

		try {
			miSession.beginTransaction();
			miSession.createQuery("delete productos where id=" + (int) id).executeUpdate();
			miSession.getTransaction().commit();
			resultado = "OK";
			miSession.close();
		} catch (Exception e) {
			resultado = e.toString();
		} finally {
			miFactory.close();
		}
		return resultado;

	}

	@Override
	public Object consultar() {

		SessionFactory miFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(ProductoDTO.class).buildSessionFactory();
		Session miSession = miFactory.openSession();
		try {
			miSession.beginTransaction();
			listaproducto = miSession.createQuery("from ProductoDTO").getResultList();
			listarproducto(listaproducto);
			miSession.getTransaction().commit();
			miSession.close();
		} catch (Exception e) {
			listaproducto = null;
			// resultado = e.toString();
		} finally {
			miFactory.close();
		}
		return listaproducto;

	}

	public int generarId() {
		int id;
		SessionFactory miFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(ProductoDTO.class).buildSessionFactory();
		Session miSession = miFactory.openSession();

		try {
			miSession.beginTransaction();
			Query query = miSession.createQuery("select max(id)+1 as id from ProductoDTO");
			List numeros = query.getResultList();
			id = (int) numeros.get(0);
			miSession.close();
		} catch (Exception e) {
			id = 1;
		} finally {
			miFactory.close();
		}
		return id;
	}

}
