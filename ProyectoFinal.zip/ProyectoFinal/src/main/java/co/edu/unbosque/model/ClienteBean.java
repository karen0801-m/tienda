package co.edu.unbosque.model;

import java.util.List;
import co.edu.unbosque.dao.ClienteDAO;
import co.edu.unbosque.dao.TiendaDAO;
import co.edu.unbosque.dto.ClienteDTO;
import co.edu.unbosque.dto.TiendaDTO;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class ClienteBean {
	private int id;
	private int cedula;
	private String nombre;
	private String direccion;
	private long telefono;
	private String correo;
	private String resultado;
	private List<ClienteDTO> listaclientes;

	public int getId() {
		return id;
	}

	public int getCedula() {
		return cedula;
	}

	public String getNombre() {
		return nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public long getTelefono() {
		return telefono;
	}

	public String getCorreo() {
		return correo;
	}

	public List<ClienteDTO> getListaclientes() {
		return listaclientes;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setCedula(int cedula) {
		this.cedula = cedula;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public void setTelefono(long telefono) {
		this.telefono = telefono;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public void setListaclientes(List<ClienteDTO> listaclientes) {
		this.listaclientes = listaclientes;
	}
	
	
	
	public String getResultado() {
		return resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}

	public String agregar() {
		ClienteDAO cl = new ClienteDAO();
		this.id = cl.generarId();
		this.resultado = cl.agregar(new ClienteDTO(this.id,this.cedula, this.nombre, this.correo, this.telefono, this.direccion));
		this.listaclientes = (List<ClienteDTO>)cl.consultar();
		if(this.resultado.equals("OK") && this.listaclientes!=null) {
			return "clientes.xhtml";
		}
		else {
			return "error.xhtml";
		}
			
	}
	
	public String eliminar(String id) {
	     ClienteDAO cl = new ClienteDAO();
	    String resultado = cl.eliminar(id);
	    this.listaclientes = (List<ClienteDTO>) cl.consultar();
	    
	    if (resultado.equals("OK")) {
	        return "tienda.xhtml";
	    } else {
	        return "error.xhtml";
	    }
	}
	
	public String actualizar() {
	    ClienteDAO cl = new ClienteDAO();
	    ClienteDTO tienda = new ClienteDTO(this.id,this.cedula, this.nombre, this.correo, this.telefono, this.direccion);
	    String resultado = cl.actualizar(this.id, tienda);
	    this.listaclientes = (List<ClienteDTO>) cl.consultar();
	    
	    if (resultado.equals("OK")) {
	        return "tienda.xhtml";
	    } else {
	        return "error.xhtml";
	    }
	}
	
	public String consultar() {
		ClienteDAO cl = new ClienteDAO();
		this.listaclientes = (List<ClienteDTO>)cl.consultar();
		if(this.listaclientes!=null) {
			return "clientes.xhtml";
		}
		else {
			return "error.xhtml";
		}
	}
	
	

}
