package co.edu.unbosque.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tienda")
public class TiendaDTO {
	@Id
	@Column(name = "id")
	private int id;

	@Column(name = "nombre")
	private String nombre;

	@Column(name = "tipo_tienda")
	private String tipo_tienda;
	
	@Column(name = "NIT")
	private long NIT;
	
	@Column(name ="Ciudad")
	private String ciudad;

	@Column(name = "valor_IVA")
	private float valor_IVA;

	@Column(name = "tasa_int")
	private float tasa_int;

	@Column(name = "banco")
	private String banco;

	@Column(name = "numerocuen")
	private long numercuen;

	@Column(name = "gerente")
	private String gerente;


    
	

	public TiendaDTO(int id, String nombre, String tipo_tienda, long nIT, String ciudad, float valor_IVA,
			float tasa_int, String banco, long numercuen, String gerente) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.tipo_tienda = tipo_tienda;
		NIT = nIT;
		this.ciudad = ciudad;
		this.valor_IVA = valor_IVA;
		this.tasa_int = tasa_int;
		this.banco = banco;
		this.numercuen = numercuen;
		this.gerente = gerente;
	}

	

	@Override
	public String toString() {
		return "TiendaDTO [id=" + id + ", nombre=" + nombre + ", tipo_tienda=" + tipo_tienda + ", NIT=" + NIT
				+ ", ciudad=" + ciudad + ", valor_IVA=" + valor_IVA + ", tasa_int=" + tasa_int + ", banco=" + banco
				+ ", numercuen=" + numercuen + ", gerente=" + gerente + "]";
	}



	public int getId() {
		return id;
	}



	public String getNombre() {
		return nombre;
	}



	public String getTipo_tienda() {
		return tipo_tienda;
	}



	public long getNIT() {
		return NIT;
	}



	public String getCiudad() {
		return ciudad;
	}



	public float getValor_IVA() {
		return valor_IVA;
	}



	public float getTasa_int() {
		return tasa_int;
	}



	public String getBanco() {
		return banco;
	}



	public long getNumercuen() {
		return numercuen;
	}



	public String getGerente() {
		return gerente;
	}



	public void setId(int id) {
		this.id = id;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public void setTipo_tienda(String tipo_tienda) {
		this.tipo_tienda = tipo_tienda;
	}



	public void setNIT(long nIT) {
		NIT = nIT;
	}



	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}



	public void setValor_IVA(float valor_IVA) {
		this.valor_IVA = valor_IVA;
	}



	public void setTasa_int(float tasa_int) {
		this.tasa_int = tasa_int;
	}



	public void setBanco(String banco) {
		this.banco = banco;
	}



	public void setNumercuen(long numercuen) {
		this.numercuen = numercuen;
	}



	public void setGerente(String gerente) {
		this.gerente = gerente;
	}



	

}
