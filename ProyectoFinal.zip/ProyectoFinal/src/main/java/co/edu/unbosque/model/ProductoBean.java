package co.edu.unbosque.model;

import co.edu.unbosque.dao.ClienteDAO;
import co.edu.unbosque.dao.ProductoDAO;
import co.edu.unbosque.dao.ProveedorDAO;
import co.edu.unbosque.dto.ClienteDTO;
import co.edu.unbosque.dto.ProductoDTO;
import co.edu.unbosque.dto.ProveedorDTO;

import java.util.List;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class ProductoBean {

	private int id;
	private long codigo_producto;
	private String nombre;
	private long NIT_prod;
	private String nombre_prov;
	private long precio_com;
	private long precio_ven;
	private String resultado;
	private List<ProductoDTO> listaproducto;

	public int getId() {
		return id;
	}

	public long getCodigo_producto() {
		return codigo_producto;
	}

	public String getNombre() {
		return nombre;
	}

	public long getNIT_prod() {
		return NIT_prod;
	}

	public String getNombre_prov() {
		return nombre_prov;
	}

	public long getPrecio_com() {
		return precio_com;
	}

	public long getPrecio_ven() {
		return precio_ven;
	}

	public List<ProductoDTO> getListaproducto() {
		return listaproducto;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setCodigo_producto(long codigo_prodcuto) {
		this.codigo_producto = codigo_prodcuto;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setNIT_prod(long nIT_prod) {
		NIT_prod = nIT_prod;
	}

	public void setNombre_prov(String nombre_prov) {
		this.nombre_prov = nombre_prov;
	}

	public void setPrecio_com(long precio_com) {
		this.precio_com = precio_com;
	}

	public void setPrecio_ven(long precio_ven) {
		this.precio_ven = precio_ven;
	}

	public void setListaproducto(List<ProductoDTO> listaproducto) {
		this.listaproducto = listaproducto;
	}

	public String agregar() {
		ProductoDAO pr = new ProductoDAO();
		this.id = pr.generarId();
		this.resultado = pr.agregar(new ProductoDTO(this.id, codigo_producto, this.nombre, NIT_prod, this.nombre_prov, precio_com, precio_ven));
		this.listaproducto = (List<ProductoDTO>)pr.consultar();
		
		if(this.resultado.equals("OK") && this.listaproducto!=null) {
			return "producto.xhtml";
		}
		else {
			return "tienda.xhtml";
		}
			
	}
	
	public String eliminar(String id) {
	     ProductoDAO pr = new ProductoDAO();
	    String resultado = pr.eliminar(id);
	    this.listaproducto = (List<ProductoDTO>) pr.consultar();
	    
	    if (resultado.equals("OK")) {
	        return "tienda.xhtml";
	    } else {
	        return "error.xhtml";
	    }
	}
	
	public String actualizar() {
	    ProductoDAO pr = new ProductoDAO();
	    ProductoDTO tienda = new ProductoDTO(this.id, codigo_producto, this.nombre, NIT_prod, this.nombre_prov, precio_com, precio_ven);
	    String resultado = pr.actualizar(this.id, tienda);
	    this.listaproducto = (List<ProductoDTO>) pr.consultar();
	    
	    if (resultado.equals("OK")) {
	        return "tienda.xhtml";
	    } else {
	        return "error.xhtml";
	    }
	}
	
}
